# Quiz Configuration constants
DIFFICULTY_EASY = "Easy"
DIFFICULTY_MEDIUM = "Medium"
DIFFICULTY_HARD = "Hard"

DIFFICULTY_LEVELS = [DIFFICULTY_EASY, DIFFICULTY_MEDIUM, DIFFICULTY_HARD]

QUESTION_MCQ = "Multiple Choice Questions (MCQ)"
QUESTION_TRUE_FALSE = "True / False"
QUESTION_FILL_BLANKS = "Fill in the Blanks"
QUESTION_SHORT_ANSWER = "Short Answer Questions"

QUESTION_TYPES = [
    QUESTION_MCQ,
    QUESTION_TRUE_FALSE,
    QUESTION_FILL_BLANKS,
    QUESTION_SHORT_ANSWER
]

# Export configuration
EXPORT_PDF = "PDF"
EXPORT_DOCX = "DOCX"
EXPORT_TXT = "TXT"

EXPORT_FORMATS = [EXPORT_PDF, EXPORT_DOCX, EXPORT_TXT]

# Session State Keys
SS_UPLOADED_FILE_HASH = "uploaded_file_hash"
SS_UPLOADED_FILE_NAME = "uploaded_file_name"
SS_VECTOR_STORE = "vector_store"
SS_PROCESSED_TEXT = "processed_text"
SS_QUIZ_HISTORY = "quiz_history"
SS_CURRENT_QUIZ = "current_quiz"
SS_CHAT_HISTORY = "chat_history"
SS_CURRENT_PAGE = "current_page"
SS_API_KEY_VALID = "api_key_valid"

# Supported LLM Providers
PROVIDER_GEMINI = "gemini"
PROVIDER_OPENAI = "openai"
PROVIDER_CUSTOM = "custom"

# Page routing values
PAGE_HOME = "home"
PAGE_QUIZ = "quiz"
PAGE_CHAT = "chatbot"

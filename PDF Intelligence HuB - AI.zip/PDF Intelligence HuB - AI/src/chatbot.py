from typing import List, Dict, Any, Tuple
from langchain_community.vectorstores import FAISS
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from src.logger import logger
from src.llm_service import LLMServiceFactory
from src.prompt_templates import CHATBOT_SYSTEM_PROMPT, CHATBOT_USER_PROMPT_TEMPLATE

class PDFChatbot:
    def __init__(self, vector_store: FAISS):
        self.vector_store = vector_store

    def _format_context(self, retrieved_docs) -> Tuple[str, List[int]]:
        """
        Formats retrieved LangChain Document objects into a single context string.
        Extracts and lists unique page numbers from the chunk metadata.
        """
        context_parts = []
        source_pages = set()
        
        for idx, doc in enumerate(retrieved_docs, 1):
            page_num = doc.metadata.get("page", "Unknown")
            if isinstance(page_num, int):
                source_pages.add(page_num)
            
            context_parts.append(
                f"--- [Snippet {idx} | Page {page_num}] ---\n"
                f"{doc.page_content}\n"
            )
            
        context_str = "\n".join(context_parts)
        sorted_pages = sorted(list(source_pages))
        return context_str, sorted_pages

    def ask(self, question: str, chat_history: List[Dict[str, str]] = None, k: int = 4) -> Dict[str, Any]:
        """
        Retrieves relevant context chunks, formats the prompt with history,
        calls the LLM, and returns the response details.
        
        chat_history format: [{'role': 'user'|'assistant', 'content': str}]
        """
        logger.info(f"Chatbot query received: '{question}'")
        
        if not question.strip():
            return {
                "answer": "Please ask a valid question.",
                "source_pages": []
            }
            
        try:
            # 1. Retrieve top-k chunks
            # We can use similarity search
            retrieved_docs = self.vector_store.similarity_search(question, k=k)
            logger.debug(f"Retrieved {len(retrieved_docs)} chunks from FAISS.")
            
            # 2. Format context and source page tracking
            context_str, source_pages = self._format_context(retrieved_docs)
            
            # 3. Construct chat context history messages
            messages = [
                SystemMessage(content=CHATBOT_SYSTEM_PROMPT)
            ]
            
            # Add past messages to system dialog to keep the model grounded in conversational context
            # We limit to the last 6 turns (3 Q&A pairs) to keep it fast and token-efficient
            if chat_history:
                recent_history = chat_history[-6:]
                for msg in recent_history:
                    if msg["role"] == "user":
                        messages.append(HumanMessage(content=msg["content"]))
                    elif msg["role"] == "assistant":
                        # Strip page source lines from previous assistant answers in context if we want,
                        # but passing directly is fine
                        messages.append(AIMessage(content=msg["content"]))
            
            # 4. Add the current prompt
            user_content = CHATBOT_USER_PROMPT_TEMPLATE.format(
                context=context_str,
                question=question
            )
            messages.append(HumanMessage(content=user_content))
            
            # 5. Call LLM
            llm = LLMServiceFactory.get_llm()
            logger.info("Calling LLM service...")
            response = llm.invoke(messages)
            
            content = response.content if hasattr(response, "content") else response
            
            if isinstance(content, list):
                answer = "".join(
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict)
                )
            else:
                answer = str(content)
                
            logger.info("Response received from LLM.")
            
            if not answer or not answer.strip():
                from src.llm_service import EmptyResponseError
                raise EmptyResponseError("Received an empty response from the Gemini model. Please try again.")
                
            return {
                "answer": answer.strip(),
                "source_pages": source_pages
            }
            
        except Exception as e:
            logger.exception(f"Error during chatbot execution: {e}")
            return {
                "answer": f"An error occurred while answering your question. Details: {str(e)}",
                "source_pages": []
            }

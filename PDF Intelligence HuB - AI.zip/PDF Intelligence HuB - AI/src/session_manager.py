import streamlit as st
from typing import Any, Dict, List
from src.logger import logger
from src.constants import *

class SessionManager:
    @staticmethod
    def initialize_session() -> None:
        """
        Ensures all necessary keys are present in Streamlit session state with default values.
        """
        defaults = {
            SS_UPLOADED_FILE_HASH: None,
            SS_UPLOADED_FILE_NAME: None,
            SS_VECTOR_STORE: None,
            SS_PROCESSED_TEXT: None,  # List[Dict[str, Any]] (extracted pages raw)
            SS_QUIZ_HISTORY: [],
            SS_CURRENT_QUIZ: None,    # List[Dict[str, Any]] (active questions generated)
            SS_CHAT_HISTORY: [],
            SS_CURRENT_PAGE: PAGE_HOME,
            SS_API_KEY_VALID: False
        }
        
        for key, val in defaults.items():
            if key not in st.session_state:
                st.session_state[key] = val
                logger.debug(f"Initialized Session State: {key} = {val}")

    @staticmethod
    def is_pdf_loaded() -> bool:
        """
        Checks if a PDF has been processed and is ready for use.
        """
        return (
            st.session_state.get(SS_UPLOADED_FILE_HASH) is not None and
            st.session_state.get(SS_PROCESSED_TEXT) is not None and
            st.session_state.get(SS_VECTOR_STORE) is not None
        )

    @staticmethod
    def get_active_file_name() -> str:
        return st.session_state.get(SS_UPLOADED_FILE_NAME, "No file uploaded")

    @staticmethod
    def clear_chat() -> None:
        """
        Clears the chat conversation log.
        """
        st.session_state[SS_CHAT_HISTORY] = []
        logger.info("Chat history cleared in session.")

    @staticmethod
    def reset_session() -> None:
        """
        Wipes all session state data, directing the user back to the home page.
        """
        logger.info("Resetting entire application session.")
        keys_to_clear = [
            SS_UPLOADED_FILE_HASH,
            SS_UPLOADED_FILE_NAME,
            SS_VECTOR_STORE,
            SS_PROCESSED_TEXT,
            SS_CURRENT_QUIZ,
            SS_CHAT_HISTORY,
            SS_QUIZ_HISTORY
        ]
        
        for key in keys_to_clear:
            st.session_state[key] = None
            
        st.session_state[SS_CHAT_HISTORY] = []
        st.session_state[SS_QUIZ_HISTORY] = []
        st.session_state[SS_CURRENT_PAGE] = PAGE_HOME
        logger.info("Session reset complete. Routed to Home.")
        
    @staticmethod
    def navigate_to(page: str) -> None:
        """
        Changes active view.
        """
        if page in [PAGE_HOME, PAGE_QUIZ, PAGE_CHAT]:
            st.session_state[SS_CURRENT_PAGE] = page
            logger.info(f"Navigated to page: {page}")
        else:
            logger.error(f"Attempted navigation to invalid page: {page}")

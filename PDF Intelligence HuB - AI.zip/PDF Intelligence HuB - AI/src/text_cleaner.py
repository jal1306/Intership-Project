import re
from typing import List, Dict, Any
from src.logger import logger

class TextCleaner:
    @staticmethod
    def clean(text: str) -> str:
        """
        Cleans raw extracted text by fixing spacing, line breaks, and standardizing whitespace.
        """
        if not text:
            return ""
            
        # Replace NUL bytes or control characters
        text = text.replace("\x00", "")
        
        # Replace multiple spaces with a single space
        text = re.sub(r"[ \t]+", " ", text)
        
        # Standardize curly quotes and hyphens
        text = text.replace("“", '"').replace("”", '"').replace("’", "'").replace("‘", "'")
        text = text.replace("–", "-").replace("—", "-")
        
        # Replace 3 or more consecutive newlines with double newlines
        text = re.sub(r"\n{3,}", "\n\n", text)
        
        # Strip leading and trailing spaces per line
        cleaned_lines = [line.strip() for line in text.split("\n")]
        text = "\n".join(cleaned_lines)
        
        return text.strip()

    @classmethod
    def clean_pages(cls, pages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Cleans the text content of all page dictionaries.
        """
        logger.info("Cleaning extracted pages text...")
        cleaned_pages = []
        for p in pages:
            cleaned_pages.append({
                "page_number": p["page_number"],
                "text": cls.clean(p["text"])
            })
        logger.info("Pages text cleaning complete.")
        return cleaned_pages

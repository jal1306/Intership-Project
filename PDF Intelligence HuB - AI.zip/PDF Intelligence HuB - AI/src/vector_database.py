import os
from typing import List
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from src.logger import logger
from src.config import config

class VectorDatabaseManager:
    @staticmethod
    def get_index_path(file_hash: str) -> str:
        """
        Returns the path where the FAISS index is saved for the given file hash.
        """
        return os.path.join(config.vector_store_dir, file_hash)

    @classmethod
    def vector_store_exists(cls, file_hash: str) -> bool:
        """
        Checks if the FAISS index files exist on disk for the given file hash.
        """
        index_path = cls.get_index_path(file_hash)
        # FAISS typically saves index.faiss and index.pkl
        faiss_file = os.path.join(index_path, "index.faiss")
        pkl_file = os.path.join(index_path, "index.pkl")
        exists = os.path.exists(faiss_file) and os.path.exists(pkl_file)
        logger.debug(f"Checking index existence for hash {file_hash}: {exists}")
        return exists

    @classmethod
    def save_vector_store(cls, vector_store: FAISS, file_hash: str) -> None:
        """
        Saves the FAISS vector store index to disk.
        """
        index_path = cls.get_index_path(file_hash)
        try:
            logger.info(f"Saving FAISS index to {index_path}...")
            os.makedirs(index_path, exist_ok=True)
            vector_store.save_local(index_path)
            logger.info("FAISS index saved successfully.")
        except Exception as e:
            logger.exception(f"Failed to save FAISS index: {e}")
            raise RuntimeError(f"Error saving vector database: {e}")

    @classmethod
    def load_vector_store(cls, file_hash: str, embeddings) -> FAISS:
        """
        Loads the FAISS vector store index from disk.
        """
        index_path = cls.get_index_path(file_hash)
        try:
            logger.info(f"Loading FAISS index from {index_path}...")
            # FAISS load_local requires allow_dangerous_deserialization=True since it loads pickle files
            vector_store = FAISS.load_local(
                index_path, 
                embeddings, 
                allow_dangerous_deserialization=True
            )
            logger.info("FAISS index loaded successfully.")
            return vector_store
        except Exception as e:
            logger.exception(f"Failed to load FAISS index: {e}")
            raise RuntimeError(f"Error loading vector database: {e}")

    @classmethod
    def create_from_documents(cls, documents: List[Document], embeddings) -> FAISS:
        """
        Creates a new FAISS vector store index from document chunks and embeddings.
        """
        try:
            logger.info(f"Creating new FAISS vector database from {len(documents)} chunks...")
            vector_store = FAISS.from_documents(documents, embeddings)
            logger.info("FAISS vector database created.")
            return vector_store
        except Exception as e:
            logger.exception(f"Failed to create FAISS vector store: {e}")
            raise RuntimeError(f"Error creating vector database: {e}")

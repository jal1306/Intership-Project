import io
from typing import List, Dict, Any
from docx import Document as DocxDocument
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

from src.logger import logger
from src.constants import QUESTION_MCQ, QUESTION_TRUE_FALSE

class ExportService:
    @staticmethod
    def export_to_txt(quiz_questions: List[Dict[str, Any]], generate_answers: bool = True) -> bytes:
        """
        Exports the quiz to plain TXT format.
        """
        logger.info("Exporting quiz to TXT...")
        lines = []
        lines.append("==================================================")
        lines.append("          PDF INTELLIGENCE HUB - AI QUIZ          ")
        lines.append("==================================================")
        lines.append("\n")

        for q in quiz_questions:
            q_num = q.get("question_number", 1)
            lines.append(f"Question {q_num}: {q.get('question', '')}\n")
            
            options = q.get("options", [])
            if options:
                # MCQ or True/False
                labels = ["A", "B", "C", "D", "E"]
                for i, opt in enumerate(options):
                    lbl = labels[i] if i < len(labels) else str(i)
                    lines.append(f"  {lbl}. {opt}")
                lines.append("\n")
                
            if generate_answers:
                lines.append(f"Answer: {q.get('answer', '')}")
                if q.get("explanation"):
                    lines.append(f"Explanation: {q.get('explanation', '')}")
                lines.append("-" * 30 + "\n")
            else:
                lines.append("\n")

        return "\n".join(lines).encode("utf-8")

    @staticmethod
    def export_to_docx(quiz_questions: List[Dict[str, Any]], generate_answers: bool = True) -> bytes:
        """
        Exports the quiz to Microsoft Word DOCX format.
        """
        logger.info("Exporting quiz to DOCX...")
        doc = DocxDocument()
        
        # Title
        title = doc.add_heading("Smart PDF Quiz", 0)
        title.alignment = 1 # Center
        
        doc.add_paragraph("Generated automatically by your AI Document Intelligence Platform.\n")

        for q in quiz_questions:
            q_num = q.get("question_number", 1)
            
            # Question block
            p = doc.add_paragraph()
            p.add_run(f"Question {q_num}: ").bold = True
            p.add_run(q.get("question", ""))
            
            # Options block
            options = q.get("options", [])
            if options:
                labels = ["A", "B", "C", "D", "E"]
                for i, opt in enumerate(options):
                    lbl = labels[i] if i < len(labels) else str(i)
                    doc.add_paragraph(f"   {lbl}. {opt}", style='List Bullet')
                    
            if generate_answers:
                # Answer / Explanation
                ans_p = doc.add_paragraph()
                ans_p.add_run("Answer: ").bold = True
                ans_p.add_run(str(q.get("answer", "")))
                
                if q.get("explanation"):
                    exp_p = doc.add_paragraph()
                    exp_p.add_run("Explanation: ").italic = True
                    exp_p.add_run(str(q.get("explanation", "")))
                    
                doc.add_paragraph().paragraph_format.space_after = 12

        # Save to bytes
        file_stream = io.BytesIO()
        doc.save(file_stream)
        file_stream.seek(0)
        return file_stream.getvalue()

    @staticmethod
    def export_to_pdf(quiz_questions: List[Dict[str, Any]], generate_answers: bool = True) -> bytes:
        """
        Exports the quiz to a highly styled PDF format using ReportLab.
        """
        logger.info("Exporting quiz to PDF...")
        buffer = io.BytesIO()
        
        # Page Setup
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=54,
            leftMargin=54,
            topMargin=54,
            bottomMargin=54
        )
        
        styles = getSampleStyleSheet()
        
        # Custom styles to fit brand colors
        title_style = ParagraphStyle(
            name="QuizTitle",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=24,
            textColor=colors.HexColor("#1A365D"), # Deep Indigo
            spaceAfter=15
        )
        
        subtitle_style = ParagraphStyle(
            name="QuizSub",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=10,
            textColor=colors.HexColor("#4A5568"), # Slate grey
            alignment=1, # Center
            spaceAfter=30
        )

        q_style = ParagraphStyle(
            name="QuizQuestion",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=12,
            textColor=colors.HexColor("#2D3748"),
            spaceBefore=12,
            spaceAfter=8,
            leading=16
        )

        opt_style = ParagraphStyle(
            name="QuizOption",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=10,
            textColor=colors.HexColor("#4A5568"),
            leftIndent=20,
            spaceAfter=5,
            leading=14
        )

        ans_style = ParagraphStyle(
            name="QuizAnswer",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=10,
            textColor=colors.HexColor("#2F855A"), # Dark Green
            leftIndent=15,
            spaceBefore=5,
            spaceAfter=4
        )

        exp_style = ParagraphStyle(
            name="QuizExplanation",
            parent=styles["Normal"],
            fontName="Helvetica-Oblique",
            fontSize=9.5,
            textColor=colors.HexColor("#718096"),
            leftIndent=15,
            spaceAfter=15,
            leading=13
        )

        story = []
        
        # Add Header
        story.append(Paragraph("PDF Intelligence HuB - AI Quiz", title_style))
        story.append(Paragraph("Generated by PDF Intelligence HuB - AI Assistant", subtitle_style))
        story.append(Spacer(1, 10))
        
        for q in quiz_questions:
            q_elements = []
            
            q_num = q.get("question_number", 1)
            q_text = f"Question {q_num}: {q.get('question', '')}"
            q_elements.append(Paragraph(q_text, q_style))
            
            options = q.get("options", [])
            if options:
                labels = ["A", "B", "C", "D", "E"]
                for i, opt in enumerate(options):
                    lbl = labels[i] if i < len(labels) else str(i)
                    opt_text = f"<b>{lbl}.</b> {opt}"
                    q_elements.append(Paragraph(opt_text, opt_style))
            
            if generate_answers:
                ans_text = f"Answer: {q.get('answer', '')}"
                q_elements.append(Paragraph(ans_text, ans_style))
                
                if q.get("explanation"):
                    exp_text = f"Explanation: {q.get('explanation', '')}"
                    q_elements.append(Paragraph(exp_text, exp_style))
            
            q_elements.append(Spacer(1, 10))
            
            # Keep each question block together on a single page if possible
            story.append(KeepTogether(q_elements))
            
        doc.build(story)
        pdf_bytes = buffer.getvalue()
        buffer.close()
        return pdf_bytes

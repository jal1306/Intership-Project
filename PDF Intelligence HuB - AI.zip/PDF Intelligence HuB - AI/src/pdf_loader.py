import os
import pdfplumber
from typing import List, Dict, Any
from pdfminer.pdfdocument import PDFPasswordIncorrect, PDFEncryptionError
from src.logger import logger


class PDFLoaderError(Exception):
    """Custom exception class for PDF loading errors."""
    pass


class PDFLoader:
    def __init__(self, file_path: str):
        self.file_path = file_path

        if not os.path.exists(file_path):
            logger.error(f"PDF file not found at path: {file_path}")
            raise PDFLoaderError(f"File not found: {file_path}")

    def load(self) -> List[Dict[str, Any]]:
        """
        Loads the PDF and extracts text page by page.

        Returns:
            [
                {
                    "page_number": 1,
                    "text": "...."
                }
            ]
        """

        logger.info(f"Starting extraction for PDF file: {self.file_path}")

        pages_content = []

        try:

            with pdfplumber.open(self.file_path) as pdf:

                total_pages = len(pdf.pages)

                if total_pages == 0:
                    logger.error("PDF contains zero pages.")
                    raise PDFLoaderError(
                        "The uploaded PDF contains no pages."
                    )

                for idx, page in enumerate(pdf.pages, start=1):

                    try:
                        text = page.extract_text()
                    except Exception as e:
                        logger.warning(
                            f"Failed to extract page {idx}: {e}"
                        )
                        text = ""

                    pages_content.append(
                        {
                            "page_number": idx,
                            "text": text.strip() if text else ""
                        }
                    )

            logger.info(
                f"Successfully extracted {len(pages_content)} pages."
            )

            total_text_len = sum(
                len(page["text"])
                for page in pages_content
            )

            if total_text_len == 0:
                logger.warning(
                    "No extractable text found inside PDF."
                )
                raise PDFLoaderError(
                    "No text could be extracted from this PDF. "
                    "It may be a scanned document (image-based PDF)."
                )

            return pages_content

        except (PDFPasswordIncorrect, PDFEncryptionError) as e:
            logger.error(f"Failed to open PDF because it is password-protected or encrypted: {e}")
            raise PDFLoaderError(
                "The PDF is encrypted or password-protected. Please upload a decrypted version."
            )

        except PDFLoaderError:
            raise

        except Exception as e:
            logger.exception(
                f"Unexpected error loading PDF: {e}"
            )
            raise PDFLoaderError(
                f"Failed to parse PDF document.\n\n{e}"
            )
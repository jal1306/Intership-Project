import json
import random
import re
from typing import List, Dict, Any

from langchain_core.messages import SystemMessage, HumanMessage

from src.logger import logger
from src.llm_service import LLMServiceFactory
from src.prompt_templates import (
    QUIZ_SYSTEM_PROMPT,
    QUIZ_USER_PROMPT_TEMPLATE,
)


class QuizGenerator:
    def __init__(self):
        pass

    def _prepare_context(self, pages: List[Dict[str, Any]], max_chars: int = 25000) -> str:
        total_text_len = sum(len(p["text"]) for p in pages)

        if total_text_len <= max_chars:
            logger.info("PDF size is within limits. Using full document context for quiz generation.")
            return "\n\n".join(
                [f"[Page {p['page_number']}]\n{p['text']}" for p in pages]
            )

        logger.info(
            f"PDF context size ({total_text_len}) exceeds limit ({max_chars}). Sampling pages..."
        )

        num_pages = len(pages)
        target_chars = int(max_chars * 0.8)

        selected_pages = []
        char_count = 0

        step = max(1, num_pages // 10)

        for idx in range(0, num_pages, step):
            page = pages[idx]

            if char_count + len(page["text"]) > target_chars:
                break

            selected_pages.append(page)
            char_count += len(page["text"])

        if pages[0] not in selected_pages:
            selected_pages.insert(0, pages[0])

        if pages[-1] not in selected_pages:
            selected_pages.append(pages[-1])

        selected_pages = sorted(selected_pages, key=lambda x: x["page_number"])

        context = "\n\n".join(
            [f"[Page {p['page_number']}]\n{p['text']}" for p in selected_pages]
        )

        logger.info(f"Prepared context length: {len(context)}")

        return context

    def _extract_response_text(self, response) -> str:
        """
        Compatible with old and latest langchain-google-genai versions.
        """

        content = getattr(response, "content", response)

        # Old SDK -> string
        if isinstance(content, str):
            return content.strip()

        # Latest SDK -> list
        if isinstance(content, list):
            text = ""

            for part in content:

                if isinstance(part, str):
                    text += part

                elif isinstance(part, dict):
                    text += part.get("text", "")

            return text.strip()

        return str(content).strip()

    def _clean_and_parse_json(self, raw_response: str):
        text = raw_response.strip()

        # Try to find markdown block ```json ... ``` or ``` ... ```
        match = re.search(r"```(?:json)?\s*(.*?)\s*```", text, re.DOTALL)
        if match:
            text_to_parse = match.group(1).strip()
            try:
                return json.loads(text_to_parse)
            except json.JSONDecodeError:
                text = text_to_parse # Fallback to more aggressive extraction on the block

        # Try parsing directly
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        logger.warning("Trying regex JSON extraction...")

        # Find the first { and the last }
        start_obj = text.find('{')
        end_obj = text.rfind('}')
        if start_obj != -1 and end_obj != -1 and end_obj > start_obj:
            try:
                return json.loads(text[start_obj:end_obj+1])
            except json.JSONDecodeError:
                pass
                
        # Also try to extract a JSON array just in case it omitted the "quiz" wrapper
        start_arr = text.find('[')
        end_arr = text.rfind(']')
        if start_arr != -1 and end_arr != -1 and end_arr > start_arr:
            try:
                parsed = json.loads(text[start_arr:end_arr+1])
                if isinstance(parsed, list):
                    return {"quiz": parsed}
            except json.JSONDecodeError:
                pass

        raise ValueError("LLM did not return valid JSON.")

    def generate_quiz(
        self,
        pages,
        question_type,
        difficulty,
        num_questions,
        shuffle=False,
    ):

        logger.info(
            f"Generating {num_questions} {question_type} ({difficulty}) questions..."
        )

        context = self._prepare_context(pages)

        llm = LLMServiceFactory.get_llm(
            temperature=0.3,
        )

        user_prompt = QUIZ_USER_PROMPT_TEMPLATE.format(
            context=context,
            question_type=question_type,
            difficulty=difficulty,
            num_questions=num_questions,
        )

        messages = [
            SystemMessage(content=QUIZ_SYSTEM_PROMPT),
            HumanMessage(content=user_prompt),
        ]

        try:

            response = llm.invoke(messages)


            content = response.content if hasattr(response, "content") else response

            # Gemini 3.x sometimes returns a list of content blocks
            if isinstance(content, list):
                raw_text = "".join(
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict)
                )
            else:
                raw_text = str(content)

            print("=" * 80)
            print(raw_text)
            print("=" * 80)
            print("RAW LENGTH:", len(raw_text))
            print("LAST 300 CHARS:")
            print(raw_text[-300:])
            print("=" * 80)
            print("=" * 80)
            logger.info(f"LLM response length: {len(raw_text)}")

            if raw_text == "":
                raise Exception("Gemini returned empty response.")

            parsed = self._clean_and_parse_json(raw_text)

            quiz = parsed.get("quiz", [])

            if not quiz:
                raise Exception("Quiz array is empty.")

            quiz = quiz[:num_questions]

            if shuffle:
                random.shuffle(quiz)

            for i, q in enumerate(quiz, start=1):
                q["question_number"] = i

            logger.info(f"Generated {len(quiz)} questions successfully.")

            return quiz

        except Exception as e:

            logger.exception(f"Quiz Generation Failed: {e}")

            raise
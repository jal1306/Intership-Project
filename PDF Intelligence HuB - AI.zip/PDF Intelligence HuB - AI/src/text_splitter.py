from typing import List, Dict, Any
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from src.logger import logger
from src.config import config

class PDFTextSplitter:
    def __init__(self, chunk_size: int = None, chunk_overlap: int = None):
        self.chunk_size = chunk_size or config.chunk_size
        self.chunk_overlap = chunk_overlap or config.chunk_overlap
        
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            length_function=len,
            separators=["\n\n", "\n", " ", ""]
        )

    def split_pages(self, cleaned_pages: List[Dict[str, Any]], source_name: str) -> List[Document]:
        """
        Splits text from each page independently. This ensures that every resulting chunk
        maps directly to its original page number, preserving perfect source tracking.
        
        Returns a list of LangChain Document objects.
        """
        logger.info(f"Splitting {len(cleaned_pages)} pages into chunks (size: {self.chunk_size}, overlap: {self.chunk_overlap})...")
        documents = []
        
        for page in cleaned_pages:
            page_num = page["page_number"]
            text = page["text"]
            
            # Skip empty pages
            if not text:
                continue
                
            # Split the page text
            chunks = self.splitter.split_text(text)
            
            for chunk_idx, chunk in enumerate(chunks):
                doc = Document(
                    page_content=chunk,
                    metadata={
                        "source": source_name,
                        "page": page_num,
                        "chunk_index": chunk_idx
                    }
                )
                documents.append(doc)
                
        logger.info(f"Split completed. Created {len(documents)} chunks from document.")
        return documents

import os
import yaml
from dotenv import load_dotenv
from src.logger import logger

class AppConfig:
    def __init__(self, config_path: str = "config.yaml"):
        # Load environment variables
        load_dotenv()
        
        self.config_data = {}
        if os.path.exists(config_path):
            try:
                with open(config_path, "r", encoding="utf-8") as f:
                    self.config_data = yaml.safe_load(f) or {}
                logger.info(f"Loaded configuration from {config_path}")
            except Exception as e:
                logger.error(f"Failed to load {config_path}: {e}. Using default configurations.")
        else:
            logger.warning(f"{config_path} not found. Using empty config base.")

        # App Configuration
        app_sec = self.config_data.get("app", {})
        self.app_name = app_sec.get("name", "PDF Intelligence HuB - AI")
        self.debug = app_sec.get("debug", True)

        # LLM Settings
        llm_sec = self.config_data.get("llm", {})
        self.llm_provider = os.getenv("LLM_PROVIDER") or llm_sec.get("provider", "gemini")
        self.gemini_model = os.getenv("GEMINI_MODEL") or llm_sec.get("gemini_model", "gemini-flash-latest")
        self.openai_model = os.getenv("OPENAI_MODEL") or llm_sec.get("openai_model", "gpt-4o-mini")
        self.custom_model = os.getenv("CUSTOM_MODEL") or llm_sec.get("custom_model", "llama-3")
        
        self.llm_model_name = os.getenv("LLM_MODEL_NAME") or llm_sec.get("model_name", self.gemini_model)
        self.llm_temperature = float(llm_sec.get("temperature", 0.2))
        self.llm_max_tokens = int(llm_sec.get("max_output_tokens", 1024))

        # Embeddings Settings
        emb_sec = self.config_data.get("embeddings", {})
        self.embeddings_provider = emb_sec.get("provider", "huggingface")
        self.gemini_emb_model = emb_sec.get("gemini_model", "text-embedding-004")
        self.openai_emb_model = emb_sec.get("openai_model", "text-embedding-3-small")
        self.huggingface_emb_model = emb_sec.get("huggingface_model", "all-MiniLM-L6-v2")
        
        provider = self.embeddings_provider.lower()
        self.embeddings_model_name = emb_sec.get("model_name") or (
            self.gemini_emb_model if provider == "gemini"
            else self.openai_emb_model if provider == "openai"
            else self.huggingface_emb_model
        )

        # Vector Store Settings
        vs_sec = self.config_data.get("vector_store", {})
        self.vector_store_dir = vs_sec.get("directory", "vector_store")
        self.chunk_size = int(vs_sec.get("chunk_size", 1000))
        self.chunk_overlap = int(vs_sec.get("chunk_overlap", 200))

        # PDF Processing Settings
        pdf_sec = self.config_data.get("pdf_processing", {})
        self.upload_dir = pdf_sec.get("upload_dir", "uploaded_pdfs")
        self.max_file_size_mb = int(pdf_sec.get("max_file_size_mb", 50))

        # Create directories if they don't exist
        os.makedirs(self.upload_dir, exist_ok=True)
        os.makedirs(self.vector_store_dir, exist_ok=True)

    @property
    def gemini_api_key(self) -> str:
        return os.getenv("GEMINI_API_KEY", "")

    @property
    def openai_api_key(self) -> str:
        return os.getenv("OPENAI_API_KEY", "")

    @property
    def custom_api_key(self) -> str:
        return os.getenv("CUSTOM_API_KEY", "")

    @property
    def custom_api_base(self) -> str:
        return os.getenv("CUSTOM_API_BASE", "")

    @property
    def custom_model_name(self) -> str:
        return os.getenv("CUSTOM_MODEL_NAME", "")

    def get_api_key(self, provider: str = None) -> str:
        """
        Helper method to retrieve the key based on the requested provider or default provider.
        """
        target = provider or self.llm_provider
        if target == "gemini":
            return self.gemini_api_key
        elif target == "openai":
            return self.openai_api_key
        elif target == "custom":
            return self.custom_api_key
        return ""

    def set_provider(self, provider: str) -> None:
        """
        Dynamically changes the active LLM provider and switches to the provider's default model.
        """
        self.llm_provider = provider
        if provider == "gemini":
            self.llm_model_name = self.gemini_model
        elif provider == "openai":
            self.llm_model_name = self.openai_model
        elif provider == "custom":
            self.llm_model_name = self.custom_model
        logger.info(f"Dynamically switched provider to '{provider}' and model to '{self.llm_model_name}'")


# Initialize global config
config = AppConfig()

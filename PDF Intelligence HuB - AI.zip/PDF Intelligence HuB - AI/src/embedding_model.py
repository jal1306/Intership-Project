from langchain_huggingface import HuggingFaceEmbeddings
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_openai import OpenAIEmbeddings
from src.logger import logger
from src.config import config

class EmbeddingModelFactory:
    _instance = None

    @classmethod
    def get_embeddings(cls):
        """
        Singleton retrieval method for embedding models.
        """
        if cls._instance is None:
            cls._instance = cls._create_embeddings()
        return cls._instance

    @classmethod
    def _create_embeddings(cls):
        provider = config.embeddings_provider.lower()
        model_name = config.embeddings_model_name
        
        logger.info(f"Initializing embedding provider: '{provider}' (model: '{model_name}')...")
        
        try:
            if provider == "huggingface":
                return HuggingFaceEmbeddings(
                    model_name=model_name,
                    model_kwargs={'device': 'cpu'}
                )
            elif provider == "gemini":
                api_key = config.gemini_api_key
                if not api_key:
                    raise ValueError("GEMINI_API_KEY is missing from environment/secrets.")
                
                # Import validation dynamically to prevent circular imports
                from src.llm_service import validate_gemini_api_key
                validate_gemini_api_key(api_key, config.llm_model_name)
                
                return GoogleGenerativeAIEmbeddings(
                    model=model_name,
                    google_api_key=api_key
                )
            elif provider == "openai":
                api_key = config.openai_api_key
                if not api_key:
                    raise ValueError("OPENAI_API_KEY is missing from environment/secrets.")
                return OpenAIEmbeddings(
                    model="text-embedding-3-small",
                    openai_api_key=api_key
                )
            else:
                logger.warning(f"Unknown embedding provider: '{provider}'. Falling back to HuggingFace.")
                return HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
                
        except Exception as e:
            logger.error(f"Failed to load embedding model: {e}. Falling back to CPU HuggingFace Embeddings.")
            # Absolute fallback
            return HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

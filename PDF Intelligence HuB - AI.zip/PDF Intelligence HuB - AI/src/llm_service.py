from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI
from src.logger import logger
from src.config import config
from src.constants import PROVIDER_GEMINI, PROVIDER_OPENAI, PROVIDER_CUSTOM

class LLMServiceError(Exception):
    pass

class MissingAPIKeyError(LLMServiceError):
    pass

class InvalidAPIKeyError(LLMServiceError):
    pass

class QuotaExceededError(LLMServiceError):
    pass

class ModelNotFoundError(LLMServiceError):
    pass

class NetworkError(LLMServiceError):
    pass

class EmptyResponseError(LLMServiceError):
    pass


def handle_gemini_api_exception(e: Exception) -> None:
    """
    Translates various API exceptions from google-genai and google-api-core
    into user-friendly custom exceptions.
    """
    err_msg = str(e).lower()
    class_name = e.__class__.__name__
    
    code = getattr(e, "code", None)
    if code is None:
        code = getattr(e, "status_code", None)
        
    message = getattr(e, "message", str(e))
    
    if class_name == "APIError" or "APIError" in class_name:
        code = getattr(e, "code", code)
        message = getattr(e, "message", message)

    logger.error(f"Gemini API Exception occurred: {class_name} | Code: {code} | Msg: {message}")

    if code in (401, 403) or "api_key_invalid" in err_msg or "invalid api key" in err_msg or "api key not valid" in err_msg or "api key is invalid" in err_msg:
        raise InvalidAPIKeyError("Invalid API Key. Please verify your GEMINI_API_KEY settings.")
    elif code == 429 or "429" in err_msg or "quota" in err_msg or "resource_exhausted" in err_msg or "exhausted" in err_msg:
        raise QuotaExceededError("Quota exceeded (429). Please try again later or check your billing plan.")
    elif code == 404 or "404" in err_msg or "model not found" in err_msg or "not found" in err_msg:
        raise ModelNotFoundError(f"Model not found (404). Please verify that the configured model name is correct and supported.")
    elif "connection" in err_msg or "dns" in err_msg or "network" in err_msg or "socket" in err_msg or "timeout" in err_msg:
        raise NetworkError("Network error: Unable to connect to Gemini API. Please check your internet connection.")
    else:
        raise LLMServiceError(f"Gemini API Error: {message}")


_validated_keys = set()

def validate_gemini_api_key(api_key: str, model_name: str) -> None:
    """
    Validates the Gemini API key using the google-genai SDK.
    Caches successful validations to avoid redundant calls.
    """
    if not api_key:
        raise MissingAPIKeyError("Gemini API Key is empty or missing.")
        
    if api_key in _validated_keys:
        return
        
    logger.info("Validating Gemini API key with google-genai Client...")
    try:
        from google import genai
        client = genai.Client(api_key=api_key)
        # Use models.list with page_size config to test connectivity and authentication
        client.models.list(config={'page_size': 1})
        _validated_keys.add(api_key)
        logger.info("Gemini API key validated successfully.")
    except Exception as e:
        logger.error(f"Gemini API key validation failed: {e}")
        handle_gemini_api_exception(e)


class LLMServiceFactory:
    @staticmethod
    def get_llm(provider: str = None, model_name: str = None, temperature: float = None):
        """
        Creates and returns a LangChain Chat LLM wrapper based on the configuration.
        """
        provider = provider or config.llm_provider
        model_name = model_name or config.llm_model_name
        temp = temperature if temperature is not None else config.llm_temperature
        
        logger.info(f"Creating LLM instance for provider: '{provider}' (model: '{model_name}', temp: {temp})")            
             
        try:
            if provider == PROVIDER_GEMINI:
                api_key = config.gemini_api_key

                if not api_key:
                    logger.error("Missing Gemini API Key.")
                    raise MissingAPIKeyError(
                        "Gemini API Key not found. Please set GEMINI_API_KEY in your environment or .env file."
                    )
                
                # Validate API key
                validate_gemini_api_key(api_key, model_name)
                
                # ChatGoogleGenerativeAI supports structure outputs and standard invocation
                try:
                    return ChatGoogleGenerativeAI(
                        model=model_name,
                        google_api_key=api_key,
                        temperature=temp,
                        max_tokens=config.llm_max_tokens,
                    )
                except Exception as e:
                    handle_gemini_api_exception(e)
                
            elif provider == PROVIDER_OPENAI:
                api_key = config.openai_api_key
                if not api_key:
                    logger.error("Missing OpenAI API Key.")
                    raise MissingAPIKeyError(
                        "OpenAI API Key not found. Please set OPENAI_API_KEY in your environment or .env file."
                    )
                return ChatOpenAI(
                    model=model_name,
                    api_key=api_key,
                    temperature=temp,
                    max_tokens=config.llm_max_tokens,
                )
                
            elif provider == PROVIDER_CUSTOM:
                api_key = config.custom_api_key
                api_base = config.custom_api_base
                custom_model = config.custom_model_name or model_name
                
                if not api_base:
                    logger.error("Missing Custom API Base URL.")
                    raise LLMServiceError(
                        "Custom LLM API Base URL not specified. Please set CUSTOM_API_BASE in your environment or .env file."
                    )
                return ChatOpenAI(
                    model=custom_model,
                    api_key=api_key or "no-key-required",
                    base_url=api_base,
                    temperature=temp,
                    max_tokens=config.llm_max_tokens,
                )
                
            else:
                logger.error(f"Unsupported LLM provider: {provider}")
                raise LLMServiceError(f"Unsupported LLM provider: {provider}")
                
        except (MissingAPIKeyError, InvalidAPIKeyError, QuotaExceededError, ModelNotFoundError, NetworkError, LLMServiceError) as e:
            raise e
        except Exception as e:
            logger.exception(f"Error initializing LLM client: {e}")
            raise LLMServiceError(f"Failed to initialize LLM client. Error: {str(e)}")

import streamlit as st
from src.constants import *
from src.session_manager import SessionManager
from src.chatbot import PDFChatbot
from ui.components import render_brand_header

def render_chatbot_page():
    """
    Renders UI for the RAG Chatbot page.
    """
    render_brand_header(
        title="AI Document Chat",
        subtitle="Ask questions related to your document. The AI replies strictly using document evidence and cites pages."
    )
    
    # Check if document is loaded, if not redirect to home
    if not SessionManager.is_pdf_loaded():
        st.warning("⚠️ No active document found. Please upload a PDF file on the home page.")
        if st.button("← Back to Home Page", use_container_width=True):
            SessionManager.navigate_to(PAGE_HOME)
            st.rerun()
        return

    # Navigation buttons
    col_nav1, col_nav2 = st.columns([3, 1])
    with col_nav1:
        if st.button("← Back to Home Dashboard", type="secondary"):
            SessionManager.navigate_to(PAGE_HOME)
            st.rerun()
    with col_nav2:
        if st.button("Clear Chat 🗑️", type="secondary", use_container_width=True):
            SessionManager.clear_chat()
            st.rerun()
            
    st.markdown(f"**Selected Document:** `{SessionManager.get_active_file_name()}`")
    st.divider()

    # 1. Display Chat History
    chat_history = st.session_state.get(SS_CHAT_HISTORY, [])
    
    for msg in chat_history:
        role = msg["role"]
        with st.chat_message(role):
            st.write(msg["content"])
            
            # Render page citations
            sources = msg.get("source_pages", [])
            if sources and role == "assistant":
                st.write("")
                pills_html = " ".join([f'<span class="page-pill">Page {p}</span>' for p in sources])
                st.markdown(f"**Sources:** {pills_html}", unsafe_allow_html=True)

    # 2. Ask Question Input
    if question := st.chat_input("Ask a question about the document..."):
        # Append User Question
        chat_history.append({"role": "user", "content": question})
        st.session_state[SS_CHAT_HISTORY] = chat_history
        
        # Display user message instantly
        with st.chat_message("user"):
            st.write(question)
            
        # Call AI Bot
        with st.chat_message("assistant"):
            # Using typing indicator spinner
            with st.spinner("Searching document & generating answer..."):
                vector_store = st.session_state[SS_VECTOR_STORE]
                chatbot = PDFChatbot(vector_store)
                
                # Fetch response
                result = chatbot.ask(question, chat_history=chat_history[:-1])
                answer = result.get("answer", "No response.")
                sources = result.get("source_pages", [])
                
                st.write(answer)
                if sources:
                    st.write("")
                    pills_html = " ".join([f'<span class="page-pill">Page {p}</span>' for p in sources])
                    st.markdown(f"**Sources:** {pills_html}", unsafe_allow_html=True)
                    
        # Append Assistant Response
        chat_history.append({
            "role": "assistant",
            "content": answer,
            "source_pages": sources
        })
        st.session_state[SS_CHAT_HISTORY] = chat_history
        st.rerun()

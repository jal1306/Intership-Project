import streamlit as st

def apply_custom_css():
    """
    Applies custom brand styling, Google fonts, cards, and transitions.
    """
    css = """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    
    h1, h2, h3, h4, h5, h6 {
        font-family: 'Outfit', sans-serif;
        font-weight: 600;
        color: #1A365D;
    }

    /* Gradient Header styling */
    .brand-title {
        background: linear-gradient(135deg, #1A365D 0%, #3182CE 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 700;
        font-size: 2.8rem;
        margin-bottom: 0.2rem;
    }

    .brand-subtitle {
        color: #4A5568;
        font-size: 1.1rem;
        margin-bottom: 2rem;
    }

    /* Glassmorphism Feature Card */
    .feature-card {
        background: rgba(255, 255, 255, 0.85);
        border: 1px solid rgba(226, 232, 240, 0.8);
        border-radius: 16px;
        padding: 24px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        text-align: left;
        margin-bottom: 1.5rem;
    }

    .feature-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 20px -3px rgba(49, 130, 206, 0.15), 0 4px 6px -2px rgba(49, 130, 206, 0.05);
        border-color: #3182CE;
    }

    .feature-icon {
        font-size: 2.2rem;
        margin-bottom: 10px;
    }

    .feature-title {
        font-size: 1.35rem;
        font-weight: 600;
        color: #2D3748;
        margin-bottom: 8px;
    }

    .feature-desc {
        font-size: 0.95rem;
        color: #718096;
        line-height: 1.5;
        margin-bottom: 16px;
    }

    /* Status Pill Badge */
    .status-badge {
        display: inline-block;
        padding: 4px 10px;
        font-size: 0.78rem;
        font-weight: 600;
        border-radius: 30px;
        margin-bottom: 5px;
    }
    
    .status-badge.success {
        background-color: #C6F6D5;
        color: #22543D;
    }
    
    .status-badge.error {
        background-color: #FED7D7;
        color: #742A2A;
    }
    
    .status-badge.info {
        background-color: #EBF8FF;
        color: #2B6CB0;
    }

    /* Citation Page Pill */
    .page-pill {
        display: inline-flex;
        align-items: center;
        background-color: #EDF2F7;
        color: #4A5568;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.8rem;
        font-weight: 600;
        margin-right: 6px;
        margin-bottom: 6px;
        border: 1px solid #CBD5E0;
    }
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)

def render_brand_header(title: str, subtitle: str):
    """
    Renders styled brand title banner.
    """
    st.markdown(f'<div class="brand-title">{title}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="brand-subtitle">{subtitle}</div>', unsafe_allow_html=True)

def render_feature_card(title: str, description: str, icon: str, button_key: str, button_label: str) -> bool:
    """
    Renders a styled feature card. Returns True if button is clicked.
    """
    st.markdown(
        f"""
        <div class="feature-card">
            <div class="feature-icon">{icon}</div>
            <div class="feature-title">{title}</div>
            <div class="feature-desc">{description}</div>
        </div>
        """,
        unsafe_allow_html=True
    )
    # Renders Streamlit button below the custom HTML container
    return st.button(button_label, key=button_key, use_container_width=True)

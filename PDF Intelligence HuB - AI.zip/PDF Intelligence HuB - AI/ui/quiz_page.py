import streamlit as st
from src.constants import *
from src.session_manager import SessionManager
from src.quiz_generator import QuizGenerator
from src.export_service import ExportService
from ui.components import render_brand_header

def render_quiz_page():
    """
    Renders UI for the AI Quiz Generator page.
    """
    render_brand_header(
        title="AI Quiz Generator",
        subtitle="Test your comprehension by generating structured quizzes directly from the uploaded document."
    )
    
    # Check if document is loaded, if not redirect to home
    if not SessionManager.is_pdf_loaded():
        st.warning("⚠️ No active document found. Please upload a PDF file on the home page.")
        if st.button("← Back to Home Page", use_container_width=True):
            SessionManager.navigate_to(PAGE_HOME)
            st.rerun()
        return

    # Back button
    if st.button("← Back to Home Dashboard", type="secondary"):
        SessionManager.navigate_to(PAGE_HOME)
        st.rerun()
        
    st.markdown(f"**Selected Document:** `{SessionManager.get_active_file_name()}`")
    
    # 1. Configuration Panel
    st.markdown("### 📝 Quiz Settings")
    
    with st.form("quiz_config_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            q_type = st.selectbox("Question Type", options=QUESTION_TYPES)
            difficulty = st.selectbox("Difficulty Level", options=DIFFICULTY_LEVELS, index=1) # Medium default
            
        with col2:
            num_questions = st.select_slider("Number of Questions", options=[5, 10, 20, 30], value=5)
            
            # Additional options
            shuffle = st.checkbox("Shuffle questions order", value=False)
            gen_explanation = st.checkbox("Include detailed answer explanations", value=True)
            
        submit_btn = st.form_submit_button("Generate Quiz ✨", use_container_width=True)
        
    # 2. Generation Logic
    if submit_btn:
        if not st.session_state.get(SS_API_KEY_VALID, False):
            st.error("API Key is missing. Please configure it in the sidebar.")
        else:
            try:
                generator = QuizGenerator()
                with st.spinner("Analyzing text and writing educational questions..."):
                    quiz = generator.generate_quiz(
                        pages=st.session_state[SS_PROCESSED_TEXT],
                        question_type=q_type,
                        difficulty=difficulty,
                        num_questions=num_questions,
                        shuffle=shuffle
                    )
                st.session_state[SS_CURRENT_QUIZ] = quiz
                st.session_state["user_answers"] = {} # Clear past answers
                st.session_state["submitted_quiz"] = False
                st.success(f"Successfully generated {len(quiz)} questions!")
            except Exception as e:
                st.error(f"Quiz generation failed: {str(e)}")

    # 3. Quiz Presentation & Interaction
    quiz_questions = st.session_state.get(SS_CURRENT_QUIZ)
    
    if quiz_questions:
        st.divider()
        st.markdown("### 🧠 Practice Test")
        
        # We render the questions inside a container
        submitted = st.session_state.get("submitted_quiz", False)
        user_answers = st.session_state.get("user_answers", {})
        
        # Display questions
        for idx, q in enumerate(quiz_questions):
            q_num = q.get("question_number", idx + 1)
            st.markdown(f"**Question {q_num}:** {q.get('question')}")
            
            options = q.get("options", [])
            q_key = f"q_input_{q_num}"
            
            if options:
                # MCQ or True/False
                # Set index to None (or default to 0 if not supported by Streamlit selectbox/radio)
                # To prevent automatic selection, we can append an empty string or show standard choices
                # But radio works great. Let's make sure it holds the answer choice.
                selected = st.radio(
                    f"Select answer for question {q_num}:",
                    options=options,
                    index=None if not submitted else options.index(user_answers.get(q_num)) if user_answers.get(q_num) in options else None,
                    key=q_key,
                    disabled=submitted,
                    label_visibility="collapsed"
                )
                if selected:
                    user_answers[q_num] = selected
            else:
                # Fill in the blanks or Short Answer
                selected_text = st.text_input(
                    f"Write answer for question {q_num}:",
                    value=user_answers.get(q_num, ""),
                    key=q_key,
                    disabled=submitted,
                    label_visibility="collapsed"
                )
                user_answers[q_num] = selected_text
                
            # If answers are submitted, show correction states
            if submitted:
                correct_ans = q.get("answer", "")
                user_ans = user_answers.get(q_num, "")
                
                is_correct = False
                if options:
                    is_correct = str(user_ans).strip().lower() == str(correct_ans).strip().lower()
                else:
                    # For open text, simple substring search or exact match
                    is_correct = str(correct_ans).strip().lower() in str(user_ans).strip().lower()
                    
                if is_correct:
                    st.markdown(f'<div class="status-badge success">✓ Correct (Your answer: {user_ans})</div>', unsafe_allow_html=True)
                else:
                    st.markdown(f'<div class="status-badge error">✗ Incorrect (Your answer: {user_ans or "empty"})</div>', unsafe_allow_html=True)
                    st.write(f"**Correct Answer:** {correct_ans}")
                    
                if gen_explanation and q.get("explanation"):
                    st.markdown(f"*Explanation:* {q.get('explanation')}")
            st.write("")
            
        st.session_state["user_answers"] = user_answers
        
        # Submit Quiz Action
        if not submitted:
            if st.button("Submit Answers ✅", use_container_width=True):
                st.session_state["submitted_quiz"] = True
                st.rerun()
        else:
            # Calculate and display score for MCQ/TF
            mcq_questions = [q for q in quiz_questions if q.get("options")]
            if mcq_questions:
                correct_count = 0
                for q in mcq_questions:
                    q_num = q["question_number"]
                    if str(user_answers.get(q_num)).strip().lower() == str(q.get("answer")).strip().lower():
                        correct_count += 1
                score_pct = (correct_count / len(mcq_questions)) * 100
                st.balloons() if score_pct >= 60 else None
                st.metric("Your Score", f"{correct_count} / {len(mcq_questions)}", f"{score_pct:.1f}% Correct")
                
            if st.button("Retake Practice Test 🔄", use_container_width=True):
                st.session_state["submitted_quiz"] = False
                st.session_state["user_answers"] = {}
                st.rerun()
                
        # 4. Export Service Panel
        st.divider()
        st.markdown("### 📤 Export Quiz")
        
        # Set up export downloads
        try:
            txt_bytes = ExportService.export_to_txt(quiz_questions, generate_answers=gen_explanation)
            docx_bytes = ExportService.export_to_docx(quiz_questions, generate_answers=gen_explanation)
            pdf_bytes = ExportService.export_to_pdf(quiz_questions, generate_answers=gen_explanation)
            
            col_txt, col_docx, col_pdf = st.columns(3)
            
            with col_txt:
                st.download_button(
                    "Download TXT 📄",
                    data=txt_bytes,
                    file_name="quiz_export.txt",
                    mime="text/plain",
                    use_container_width=True
                )
                
            with col_docx:
                st.download_button(
                    "Download Word (DOCX) 🟦",
                    data=docx_bytes,
                    file_name="quiz_export.docx",
                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    use_container_width=True
                )
                
            with col_pdf:
                st.download_button(
                    "Download PDF 📕",
                    data=pdf_bytes,
                    file_name="quiz_export.pdf",
                    mime="application/pdf",
                    use_container_width=True
                )
        except Exception as e:
            st.error(f"Failed to generate download formats: {e}")

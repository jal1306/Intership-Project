import os
import streamlit as st
from src.constants import *
from src.session_manager import SessionManager
from src.config import config

def render_sidebar():
    """
    Renders settings sidebar containing logo, API validation and session management.
    """
    with st.sidebar:
        st.markdown("### ⚙️ Platform Settings")
        
        # 1. API Configuration
        st.subheader("🔑 AI API Configuration")
        
        # Check defaults from config/env
        provider_options = [PROVIDER_GEMINI, PROVIDER_OPENAI, PROVIDER_CUSTOM]
        current_provider = st.selectbox(
            "Select AI Provider",
            options=provider_options,
            index=provider_options.index(config.llm_provider) if config.llm_provider in provider_options else 0,
            help="Choose the model hosting provider."
        )
        
        # Keep config synced and switch default models cleanly
        if current_provider != config.llm_provider:
            config.set_provider(current_provider)
        
        api_key_input = ""
        if current_provider == PROVIDER_GEMINI:
            default_key = os.environ.get("GEMINI_API_KEY") or config.gemini_api_key
            api_key_input = st.text_input(
                "Gemini API Key",
                value=default_key,
                type="password",
                placeholder="AIzaSy..."
            )
            if api_key_input:
                os.environ["GEMINI_API_KEY"] = api_key_input
                
        elif current_provider == PROVIDER_OPENAI:
            default_key = os.environ.get("OPENAI_API_KEY") or config.openai_api_key
            api_key_input = st.text_input(
                "OpenAI API Key",
                value=default_key,
                type="password",
                placeholder="sk-proj-..."
            )
            if api_key_input:
                os.environ["OPENAI_API_KEY"] = api_key_input
                
        elif current_provider == PROVIDER_CUSTOM:
            api_base = st.text_input(
                "API Base URL",
                value=os.environ.get("CUSTOM_API_BASE") or config.custom_api_base,
                placeholder="http://localhost:8000/v1"
            )
            if api_base:
                os.environ["CUSTOM_API_BASE"] = api_base
                
            default_key = os.environ.get("CUSTOM_API_KEY") or config.custom_api_key
            api_key_input = st.text_input(
                "Custom API Key",
                value=default_key,
                type="password",
                placeholder="optional"
            )
            if api_key_input:
                os.environ["CUSTOM_API_KEY"] = api_key_input
                
            custom_model = st.text_input(
                "Model Name",
                value=os.environ.get("CUSTOM_MODEL_NAME") or config.custom_model_name or "llama-3",
                placeholder="e.g. llama-3"
            )
            if custom_model:
                os.environ["CUSTOM_MODEL_NAME"] = custom_model
                config.llm_model_name = custom_model

        # Show verification badge / perform validation
        if current_provider == PROVIDER_GEMINI:
            if api_key_input:
                from src.llm_service import validate_gemini_api_key, LLMServiceError
                try:
                    validate_gemini_api_key(api_key_input, config.llm_model_name)
                    st.markdown('<div class="status-badge success">✓ API Key Validated</div>', unsafe_allow_html=True)
                    st.session_state[SS_API_KEY_VALID] = True
                except LLMServiceError as e:
                    st.markdown(f'<div class="status-badge error">✗ API Key Invalid: {str(e)}</div>', unsafe_allow_html=True)
                    st.session_state[SS_API_KEY_VALID] = False
                except Exception as e:
                    st.markdown(f'<div class="status-badge error">✗ Error: {str(e)}</div>', unsafe_allow_html=True)
                    st.session_state[SS_API_KEY_VALID] = False
            else:
                st.markdown('<div class="status-badge error">✗ API Key Missing</div>', unsafe_allow_html=True)
                st.session_state[SS_API_KEY_VALID] = False
        else:
            # Other providers (no key validation method available)
            has_key = bool(api_key_input) or (current_provider == PROVIDER_CUSTOM and os.environ.get("CUSTOM_API_BASE"))
            if has_key:
                st.markdown('<div class="status-badge success">✓ API Configured</div>', unsafe_allow_html=True)
                st.session_state[SS_API_KEY_VALID] = True
            else:
                st.markdown('<div class="status-badge error">✗ API Key Missing</div>', unsafe_allow_html=True)
                st.session_state[SS_API_KEY_VALID] = False
            
        st.divider()
        
        # 2. Uploaded Document Info
        if SessionManager.is_pdf_loaded():
            st.subheader("📄 Active Document")
            st.write(f"**Name:** {st.session_state[SS_UPLOADED_FILE_NAME]}")
            
            pages_list = st.session_state[SS_PROCESSED_TEXT]
            st.write(f"**Pages:** {len(pages_list) if pages_list else 0}")
            
            # Reset Button
            st.subheader("🔄 Session Control")
            if st.button("Reset Document Session", type="secondary", use_container_width=True):
                SessionManager.reset_session()
                st.rerun()
        else:
            st.info("Upload a PDF to view metadata details.")
            
        st.divider()
        st.markdown(
            """
            <div style="font-size: 0.8rem; color: #718096; text-align: center;">
                PDF Intelligence HuB - AI v1.0<br>
                Powered by FAISS & LangChain
            </div>
            """, 
            unsafe_allow_html=True
        )

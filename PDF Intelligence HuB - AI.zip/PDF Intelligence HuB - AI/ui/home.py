import os
import hashlib
import json
import streamlit as st
from src.constants import *
from src.session_manager import SessionManager
from src.pdf_loader import PDFLoader, PDFLoaderError
from src.text_cleaner import TextCleaner
from src.text_splitter import PDFTextSplitter
from src.embedding_model import EmbeddingModelFactory
from src.vector_database import VectorDatabaseManager
from src.config import config
from ui.components import render_brand_header, render_feature_card

def get_file_hash(file_bytes: bytes) -> str:
    """Calculates MD5 hash of file bytes to verify caching."""
    return hashlib.md5(file_bytes).hexdigest()

def process_pdf(uploaded_file) -> None:
    """
    Core document processing workflow. Integrates loader, cleaner, splitter,
    embeddings generation and FAISS storage. Includes caching mechanism.
    """
    file_bytes = uploaded_file.read()
    file_hash = get_file_hash(file_bytes)
    file_name = uploaded_file.name
    
    # Create absolute folder paths
    os.makedirs("uploaded_pdfs", exist_ok=True)
    temp_pdf_path = os.path.join("uploaded_pdfs", f"{file_hash}.pdf")
    
    # Save the file locally
    with open(temp_pdf_path, "wb") as f:
        f.write(file_bytes)
        
    index_path = VectorDatabaseManager.get_index_path(file_hash)
    pages_json_path = os.path.join(index_path, "pages.json")
    
    try:
        # Cache Hit Check
        if VectorDatabaseManager.vector_store_exists(file_hash) and os.path.exists(pages_json_path):
            st.info("⚡ Pre-processed document detected. Loading from local database cache...")
            
            with st.spinner("Retrieving text index..."):
                embeddings = EmbeddingModelFactory.get_embeddings()
                vector_store = VectorDatabaseManager.load_vector_store(file_hash, embeddings)
                
                with open(pages_json_path, "r", encoding="utf-8") as f:
                    processed_text = json.load(f)
                    
            st.session_state[SS_UPLOADED_FILE_HASH] = file_hash
            st.session_state[SS_UPLOADED_FILE_NAME] = file_name
            st.session_state[SS_VECTOR_STORE] = vector_store
            st.session_state[SS_PROCESSED_TEXT] = processed_text
            st.success("✅ Document loaded successfully in 0.1s!")
            return

        # Cache Miss - Process PDF from Scratch
        st.write("🔄 Processing new document. This might take a few moments depending on size...")
        
        # Step 1: Extract Text
        with st.spinner("Extracting text from PDF pages..."):
            loader = PDFLoader(temp_pdf_path)
            raw_pages = loader.load()
            
        # Step 2: Clean Text
        with st.spinner("Cleaning and formatting text structure..."):
            cleaned_pages = TextCleaner.clean_pages(raw_pages)
            
        # Step 3: Split into Chunks
        with st.spinner("Splitting document into token-safe semantic chunks..."):
            splitter = PDFTextSplitter()
            doc_chunks = splitter.split_pages(cleaned_pages, source_name=file_name)
            
        # Step 4: Generate Embeddings and Save in FAISS
        with st.spinner("Generating vector embeddings & creating FAISS database..."):
            embeddings = EmbeddingModelFactory.get_embeddings()
            vector_store = VectorDatabaseManager.create_from_documents(doc_chunks, embeddings)
            
            # Save local FAISS files
            VectorDatabaseManager.save_vector_store(vector_store, file_hash)
            
            # Save raw pages json alongside FAISS index
            with open(pages_json_path, "w", encoding="utf-8") as f:
                json.dump(cleaned_pages, f)
                
        # Register in session
        st.session_state[SS_UPLOADED_FILE_HASH] = file_hash
        st.session_state[SS_UPLOADED_FILE_NAME] = file_name
        st.session_state[SS_VECTOR_STORE] = vector_store
        st.session_state[SS_PROCESSED_TEXT] = cleaned_pages
        
        st.success("🎉 PDF Pipeline completed! Document vectors generated and saved.")
        
    except PDFLoaderError as pe:
        st.error(f"File Loading Error: {str(pe)}")
    except Exception as e:
        st.error(f"Failed to process document: {str(e)}")
        # Delete corrupt local files if any
        if os.path.exists(temp_pdf_path):
            os.remove(temp_pdf_path)

def render_home_page():
    """
    Renders Home upload area and navigation controls.
    """
    render_brand_header(
        title="PDF Intelligence HuB - AI",
        subtitle="Upload your document once, generate interactive educational quizzes, and chat with AI grounded in your text."
    )
    
    # Warning if API key is not valid
    if not st.session_state.get(SS_API_KEY_VALID, False):
        st.warning("⚠️ Action Required: Please input your API Key in the left sidebar configuration to activate features.")
        
    # File Uploader Container
    st.markdown("### 📥 1. Upload Document")
    uploaded_file = st.file_uploader(
        "Choose a PDF file",
        type=["pdf"],
        help="Upload any PDF file up to 50MB."
    )
    
    # Process Button logic
    if uploaded_file is not None:
        file_size_mb = len(uploaded_file.getvalue()) / (1024 * 1024)
        if file_size_mb > config.max_file_size_mb:
            st.error(f"The file size ({file_size_mb:.1f}MB) exceeds the maximum allowed limit of {config.max_file_size_mb}MB.")
        else:
            is_processed = SessionManager.is_pdf_loaded() and st.session_state[SS_UPLOADED_FILE_NAME] == uploaded_file.name
            
            # Show processing panel
            if not is_processed:
                if st.button("Process Document ⚙️", type="primary", use_container_width=True):
                    process_pdf(uploaded_file)
                    st.rerun()
            else:
                st.success(f"✓ '{uploaded_file.name}' is loaded and ready for analysis.")
                
    st.divider()
    
    # Feature Cards (active only after PDF processed)
    st.markdown("### 🛠️ 2. Select AI Feature")
    
    col1, col2 = st.columns(2)
    
    with col1:
        quiz_click = render_feature_card(
            title="AI Quiz Generator",
            description="Create custom Multiple Choice, True/False, or Short Answer tests directly from your PDF sections. Export to Word, PDF or Text.",
            icon="📝",
            button_key="goto_quiz_btn",
            button_label="Open Quiz Generator"
        )
        
    with col2:
        chat_click = render_feature_card(
            title="AI PDF Chatbot",
            description="Ask questions and receive instant answers grounded in your document. Includes conversation log history and exact page references.",
            icon="💬",
            button_key="goto_chat_btn",
            button_label="Open Document Chat"
        )
        
    # Navigation routing
    if quiz_click:
        if SessionManager.is_pdf_loaded():
            SessionManager.navigate_to(PAGE_QUIZ)
            st.rerun()
        else:
            st.error("Please upload and process a PDF document before accessing this feature.")
            
    if chat_click:
        if SessionManager.is_pdf_loaded():
            SessionManager.navigate_to(PAGE_CHAT)
            st.rerun()
        else:
            st.error("Please upload and process a PDF document before accessing this feature.")

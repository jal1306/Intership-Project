import os
from src.vector_database import VectorDatabaseManager

def test_get_index_path():
    file_hash = "mock_hash_123"
    index_path = VectorDatabaseManager.get_index_path(file_hash)
    # The default directory is "vector_store" from config.yaml
    assert "vector_store" in index_path
    assert file_hash in index_path

def test_vector_store_exists_false_for_missing():
    # Verify that a random hash returns false because it has no saved FAISS index
    assert not VectorDatabaseManager.vector_store_exists("random_unseen_hash_abc123")

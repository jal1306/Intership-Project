import pytest
from src.pdf_loader import PDFLoader, PDFLoaderError

def test_missing_pdf_raises_error():
    """Ensure opening a non-existent path correctly raises PDFLoaderError."""
    with pytest.raises(PDFLoaderError) as exc_info:
        PDFLoader("non_existent_file.pdf")
    assert "File not found" in str(exc_info.value)

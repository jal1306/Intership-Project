import pytest
from src.text_cleaner import TextCleaner

def test_clean_spaces():
    raw_text = "Hello   world!  This\tcontains \t tabs."
    cleaned = TextCleaner.clean(raw_text)
    assert cleaned == "Hello world! This contains tabs."

def test_clean_quotes_and_dashes():
    raw_text = "“Double quotes” and ’single quotes’ with – and — dashes."
    cleaned = TextCleaner.clean(raw_text)
    assert cleaned == '"Double quotes" and \'single quotes\' with - and - dashes.'

def test_clean_newlines():
    raw_text = "Line 1\n\n\nLine 2\n\n\n\n\nLine 3"
    cleaned = TextCleaner.clean(raw_text)
    assert cleaned == "Line 1\n\nLine 2\n\nLine 3"

def test_clean_pages():
    pages = [
        {"page_number": 1, "text": "  Raw  page   1  text.  "},
        {"page_number": 2, "text": "Raw \t page 2\n\n\ntext."}
    ]
    cleaned_pages = TextCleaner.clean_pages(pages)
    assert len(cleaned_pages) == 2
    assert cleaned_pages[0]["text"] == "Raw page 1 text."
    assert cleaned_pages[1]["text"] == "Raw page 2\n\ntext."

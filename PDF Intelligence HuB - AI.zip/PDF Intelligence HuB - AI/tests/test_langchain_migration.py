import pytest
from src.text_splitter import PDFTextSplitter
from src.embedding_model import EmbeddingModelFactory
from src.llm_service import LLMServiceFactory
from src.constants import PROVIDER_GEMINI, PROVIDER_OPENAI
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings

def test_recursive_character_text_splitter_import():
    """Ensure the text splitter is imported from the correct package."""
    assert RecursiveCharacterTextSplitter is not None
    splitter = PDFTextSplitter(chunk_size=500, chunk_overlap=50)
    assert splitter.chunk_size == 500
    assert splitter.chunk_overlap == 50

def test_huggingface_embeddings_import():
    """Ensure HuggingFaceEmbeddings is imported from the new package."""
    assert HuggingFaceEmbeddings is not None
    embeddings = EmbeddingModelFactory.get_embeddings()
    assert embeddings is not None
